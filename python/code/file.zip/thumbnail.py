from PIL import Image

size = (128, 128)
saved = "lenna.jpeg"

im =  Image.open("Lenna.png")
im.thumbnail(size)
im.save(saved)
im.show()
